<?php
session_start();
 $required_role = 'admin';
require_once '../config/auth_check.php';
require_once '../config/db.php';
require_once 'admin_init.php';

 $pageTitle = 'Edit User - GxAlert';
 $form_errors = [];
 $old = [];
 $notify_text = '';

 $id = (int)($_GET['id'] ?? 0);
if ($id === 0) { header("Location: users.php"); exit; }

 $u_stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
 $u_stmt->bind_param("i", $id);
 $u_stmt->execute();
 $u_res = $u_stmt->get_result();
if ($u_res->num_rows !== 1) { header("Location: users.php"); exit; }
 $user = $u_res->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fields = ['name','email','role','location','phone'];
    foreach ($fields as $f) $old[$f] = trim($_POST[$f] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if (empty($old['name'])) $form_errors['name'] = 'Name is required';
    if (empty($old['email'])) $form_errors['email'] = 'Email is required';
    elseif (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) $form_errors['email'] = 'Invalid email';
    else {
        $ck = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $ck->bind_param("si", $old['email'], $id);
        $ck->execute();
        if ($ck->get_result()->num_rows > 0) $form_errors['email'] = 'Email already in use';
    }
    if (!isset($role_labels[$old['role']])) $form_errors['role'] = 'Invalid role';
    if (!empty($password) && strlen($password) < 8) $form_errors['password'] = 'Minimum 8 characters';
    if (!empty($password) && $password !== $confirm) $form_errors['confirm_password'] = 'Passwords do not match';

    if (empty($form_errors)) {
        if (!empty($password)) {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $upd = $conn->prepare("UPDATE users SET name=?, email=?, role=?, location=?, phone=?, password=? WHERE id=?");
            $upd->bind_param("ssssssi", $old['name'], $old['email'], $old['role'], $old['location'], $old['phone'], $hashed, $id);
        } else {
            $upd = $conn->prepare("UPDATE users SET name=?, email=?, role=?, location=?, phone=? WHERE id=?");
            $upd->bind_param("sssssi", $old['name'], $old['email'], $old['role'], $old['location'], $old['phone'], $id);
        }
        $upd->execute();
        
        // Log audit
        $audit = $conn->prepare("INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details, created_at) VALUES (?, 'update', 'user', ?, ?, NOW())");
        $audit->bind_param("iis", $admin_id, $id, json_encode($old));
        $audit->execute();
        
        $notify_text = 'updated';
        
        // Refresh user data
        $u_stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
        $u_stmt->bind_param("i", $id);
        $u_stmt->execute();
        $user = $u_stmt->get_result()->fetch_assoc();
    }
} else {
    $old = $user;
}
?>
<?php require_once 'admin_header.php'; ?>

<main class="main-content w-full px-[var(--margin-x)] pb-8">
  <div class="mt-4 max-w-2xl">
    <div class="flex items-center gap-3 mb-6">
      <a href="users.php" class="btn size-9 rounded-full p-0 hover:bg-slate-200 dark:hover:bg-navy-600">
        <svg class="size-5" fill="none" viewbox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M15 19l-7-7 7-7"/></svg>
      </a>
      <h1 class="text-xl font-semibold text-slate-700 dark:text-navy-100">Edit User</h1>
      <span class="inline-flex rounded-full px-2.5 py-0.5 text-xs font-medium <?= $role_colors[$user['role']] ?? '' ?>">
        <?= $role_labels[$user['role']] ?? $user['role'] ?>
      </span>
    </div>

    <?php if (!empty($form_errors)): ?>
    <div class="alert mb-4 flex overflow-hidden rounded-lg bg-error/10 text-error dark:bg-error/15">
      <div class="flex flex-1 items-center space-x-3 p-4">
        <svg class="size-5 shrink-0" fill="none" viewbox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
        <div class="flex-1 text-sm"><?= implode('<br>', array_map('htmlspecialchars', $form_errors)) ?></div>
      </div>
      <div class="w-1.5 bg-error"></div>
    </div>
    <?php endif; ?>

    <form method="POST" class="card p-5 space-y-5">
      <div>
        <label class="block text-sm font-medium text-slate-700 dark:text-navy-100 mb-1">Full Name *</label>
        <input type="text" name="name" value="<?= htmlspecialchars($old['name'] ?? '') ?>" required
               class="form-input w-full rounded-lg bg-slate-150 py-2 px-3 text-sm ring-primary/50 dark:bg-navy-900/90 dark:ring-accent/50">
      </div>

      <div>
        <label class="block text-sm font-medium text-slate-700 dark:text-navy-100 mb-1">Email Address *</label>
        <input type="email" name="email" value="<?= htmlspecialchars($old['email'] ?? '') ?>" required
               class="form-input w-full rounded-lg bg-slate-150 py-2 px-3 text-sm ring-primary/50 dark:bg-navy-900/90 dark:ring-accent/50">
      </div>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
        <div>
          <label class="block text-sm font-medium text-slate-700 dark:text-navy-100 mb-1">Role *</label>
          <select name="role" required class="form-select w-full rounded-lg bg-slate-150 py-2 px-3 text-sm dark:bg-navy-900/90">
            <?php foreach ($role_labels as $k => $v): ?>
            <option value="<?= $k ?>" <?= ($old['role'] ?? '') === $k ? 'selected' : '' ?>><?= $v ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label class="block text-sm font-medium text-slate-700 dark:text-navy-100 mb-1">Phone</label>
          <input type="text" name="phone" value="<?= htmlspecialchars($old['phone'] ?? '') ?>"
                 class="form-input w-full rounded-lg bg-slate-150 py-2 px-3 text-sm ring-primary/50 dark:bg-navy-900/90 dark:ring-accent/50">
        </div>
      </div>

      <div>
        <label class="block text-sm font-medium text-slate-700 dark:text-navy-100 mb-1">Location / Facility</label>
        <input type="text" name="location" value="<?= htmlspecialchars($old['location'] ?? '') ?>"
               class="form-input w-full rounded-lg bg-slate-150 py-2 px-3 text-sm ring-primary/50 dark:bg-navy-900/90 dark:ring-accent/50">
      </div>

      <div class="my-3 h-px bg-slate-200 dark:bg-navy-500"></div>
      <p class="text-sm text-slate-500 dark:text-navy-300">Leave password fields empty to keep current password.</p>

      <div class="grid grid-cols-1 sm:grid-cols-2 gap-5">
        <div>
          <label class="block text-sm font-medium text-slate-700 dark:text-navy-100 mb-1">New Password</label>
          <input type="password" name="password" minlength="8"
                 class="form-input w-full rounded-lg bg-slate-150 py-2 px-3 text-sm ring-primary/50 dark:bg-navy-900/90 dark:ring-accent/50">
        </div>
        <div>
          <label class="block text-sm font-medium text-slate-700 dark:text-navy-100 mb-1">Confirm New Password</label>
          <input type="password" name="confirm_password"
                 class="form-input w-full rounded-lg bg-slate-150 py-2 px-3 text-sm ring-primary/50 dark:bg-navy-900/90 dark:ring-accent/50">
        </div>
      </div>

      <div class="flex items-center justify-between pt-2">
        <div class="text-xs text-slate-400">
          Created: <?= $user['created_at'] ?> | Last login: <?= $user['last_login'] ?? 'Never' ?>
        </div>
        <div class="flex space-x-3">
          <a href="users.php" class="btn h-10 border border-slate-300 text-slate-600 hover:bg-slate-100 dark:border-navy-500 dark:text-navy-200 dark:hover:bg-navy-600 px-6">Cancel</a>
          <button type="submit" class="btn h-10 bg-primary text-white hover:bg-primary-focus dark:bg-accent dark:hover:bg-accent-focus px-6">Save Changes</button>
        </div>
      </div>
    </form>
  </div>
</main>

<?php $notify_variant = 'success'; require_once 'admin_footer.php'; ?>