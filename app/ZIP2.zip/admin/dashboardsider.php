<div class="sidebar-panel">
  <div class="flex h-full grow flex-col bg-white pl-[var(--main-sidebar-width)] dark:bg-navy-750">
    <div class="flex h-18 w-full items-center justify-between pl-4 pr-1">
      <p class="text-base tracking-wider text-slate-800 dark:text-navy-100">Menu</p>
      <button @click="$store.global.isSidebarExpanded = false" class="btn size-7 rounded-full p-0 text-primary hover:bg-slate-300/20 focus:bg-slate-300/20 active:bg-slate-300/25 dark:text-accent-light/80 dark:hover:bg-navy-300/20 dark:focus:bg-navy-300/20 dark:active:bg-navy-300/25 xl:hidden">
        <svg xmlns="http://www.w3.org/2000/svg" class="size-6" fill="none" viewbox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>
      </button>
    </div>
    <div x-data="{expandedItem:null}" class="h-[calc(100%-4.5rem)] overflow-x-hidden pb-6" x-init="$el._x_simplebar = new SimpleBar($el);">
      <ul class="flex flex-1 flex-col px-4 font-inter">
        <li><a x-data="navLink" href="index.php" :class="isActive ? 'font-medium text-primary dark:text-accent-light' : 'text-slate-600 hover:text-slate-900 dark:text-navy-200 dark:hover:text-navy-50'" class="flex py-2 text-xs+ tracking-wide outline-none transition-colors duration-300">Dashboard</a></li>
      </ul>
      <div class="my-3 mx-4 h-px bg-slate-200 dark:bg-navy-500"></div>
      <ul class="flex flex-1 flex-col px-4 font-inter">
        <li x-data="accordionItem('admin-manage')">
          <a :class="expanded ? 'text-slate-800 font-semibold dark:text-navy-50' : 'text-slate-600 dark:text-navy-200 hover:text-slate-800 dark:hover:text-navy-50'" @click="expanded = !expanded" class="flex items-center justify-between py-2 text-xs+ tracking-wide outline-none transition-colors duration-300" href="javascript:void(0);">
            <span>Management</span>
            <svg :class="expanded && 'rotate-90'" xmlns="http://www.w3.org/2000/svg" class="size-4 text-slate-400 transition-transform ease-in-out" fill="none" viewbox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
          </a>
          <ul x-collapse x-show="expanded">
            <li><a x-data="navLink" href="users.php" :class="isActive ? 'font-medium text-primary dark:text-accent-light' : 'text-slate-600 hover:text-slate-900 dark:text-navy-200 dark:hover:text-navy-50'" class="flex items-center justify-between p-2 text-xs+ tracking-wide outline-none transition-colors duration-300 hover:pl-4"><div class="flex items-center space-x-2"><div class="size-1.5 rounded-full border border-current opacity-40"></div><span>Users</span></div></a></li>
            <li><a x-data="navLink" href="adduser.php" :class="isActive ? 'font-medium text-primary dark:text-accent-light' : 'text-slate-600 hover:text-slate-900 dark:text-navy-200 dark:hover:text-navy-50'" class="flex items-center justify-between p-2 text-xs+ tracking-wide outline-none transition-colors duration-300 hover:pl-4"><div class="flex items-center space-x-2"><div class="size-1.5 rounded-full border border-current opacity-40"></div><span>Add User</span></div></a></li>
            <li><a x-data="navLink" href="facilities.php" :class="isActive ? 'font-medium text-primary dark:text-accent-light' : 'text-slate-600 hover:text-slate-900 dark:text-navy-200 dark:hover:text-navy-50'" class="flex items-center justify-between p-2 text-xs+ tracking-wide outline-none transition-colors duration-300 hover:pl-4"><div class="flex items-center space-x-2"><div class="size-1.5 rounded-full border border-current opacity-40"></div><span>Facilities</span></div></a></li>
            <li><a x-data="navLink" href="drugs.php" :class="isActive ? 'font-medium text-primary dark:text-accent-light' : 'text-slate-600 hover:text-slate-900 dark:text-navy-200 dark:hover:text-navy-50'" class="flex items-center justify-between p-2 text-xs+ tracking-wide outline-none transition-colors duration-300 hover:pl-4"><div class="flex items-center space-x-2"><div class="size-1.5 rounded-full border border-current opacity-40"></div><span>Drug Catalog</span></div></a></li>
          </ul>
        </li>
        <li x-data="accordionItem('admin-logs')">
          <a :class="expanded ? 'text-slate-800 font-semibold dark:text-navy-50' : 'text-slate-600 dark:text-navy-200 hover:text-slate-800 dark:hover:text-navy-50'" @click="expanded = !expanded" class="flex items-center justify-between py-2 text-xs+ tracking-wide outline-none transition-colors duration-300" href="javascript:void(0);">
            <span>Logs</span>
            <svg :class="expanded && 'rotate-90'" xmlns="http://www.w3.org/2000/svg" class="size-4 text-slate-400 transition-transform ease-in-out" fill="none" viewbox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
          </a>
          <ul x-collapse x-show="expanded">
            <li><a x-data="navLink" href="audit_logs.php" :class="isActive ? 'font-medium text-primary dark:text-accent-light' : 'text-slate-600 hover:text-slate-900 dark:text-navy-200 dark:hover:text-navy-50'" class="flex items-center justify-between p-2 text-xs+ tracking-wide outline-none transition-colors duration-300 hover:pl-4"><div class="flex items-center space-x-2"><div class="size-1.5 rounded-full border border-current opacity-40"></div><span>Audit Trail</span></div></a></li>
            <li><a x-data="navLink" href="sms_logs.php" :class="isActive ? 'font-medium text-primary dark:text-accent-light' : 'text-slate-600 hover:text-slate-900 dark:text-navy-200 dark:hover:text-navy-50'" class="flex items-center justify-between p-2 text-xs+ tracking-wide outline-none transition-colors duration-300 hover:pl-4"><div class="flex items-center space-x-2"><div class="size-1.5 rounded-full border border-current opacity-40"></div><span>SMS Logs</span></div></a></li>
          </ul>
        </li>
      </ul>
      <div class="my-3 mx-4 h-px bg-slate-200 dark:bg-navy-500"></div>
      <ul class="flex flex-1 flex-col px-4 font-inter">
        <li><a x-data="navLink" href="settings.php" :class="isActive ? 'font-medium text-primary dark:text-accent-light' : 'text-slate-600 hover:text-slate-900 dark:text-navy-200 dark:hover:text-navy-50'" class="flex py-2 text-xs+ tracking-wide outline-none transition-colors duration-300">Settings</a></li>
      </ul>
    </div>
  </div>
</div>